import React, { useState } from 'react';
import { db, storage } from '../Config/firebase';
import { collection, addDoc, Timestamp } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import Modal from "./Modal";

function AddProject({ onClose, open }) {
    const [title, setTitle] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [status, setStatus] = useState('');
    const [image, setImage] = useState(null);
    const [error, setError] = useState(null);

    const handleImageChange = (e) => {
        if (e.target.files[0]) {
            setImage(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!title.trim() || !startDate || !endDate || !status) {
            setError('All fields are required!');
            return;
        }
        if (!image) {
            setError('Image is required!');
            return;
        }
        try {
            setError(null);
            const imageRef = ref(storage, `images/${image.name}`);
            const uploadTask = uploadBytesResumable(imageRef, image);
            uploadTask.on('state_changed',
                null,
                (error) => setError('Image upload failed.'),
                async () => {
                    const downloadURL = await getDownloadURL(imageRef);
                    await addDoc(collection(db, 'projects'), {
                        title: title.trim(),
                        startDate,
                        endDate,
                        status,
                        imageUrl: downloadURL,
                        created: Timestamp.now(),
                    });
                    onClose();
                    alert('Project added successfully!');
                }
            );
        } catch (err) {
            setError('Error adding project. Please try again later.');
        }
    };

    return (
        <div className='w-full h-full pt-[10rem] px-5 fixed z-[1000] top-0 left-0 right-0 bottom-0 backdrop-blur-md py-5 flex items-center justify-center'>
            <Modal modalLable='Add Project' onClose={onClose} open={open}>
                <form name='addProject' onSubmit={handleSubmit} className="form">
                    <input type="text" name="title" onChange={(e) => setTitle(e.target.value)} value={title} placeholder="Project Name" className='input' />
                    <input type="date" name="startDate" onChange={(e) => setStartDate(e.target.value)} value={startDate} className='input' />
                    <input type="date" name="endDate" onChange={(e) => setEndDate(e.target.value)} value={endDate} className='input' />
                    <input type="text" name="status" onChange={(e) => setStatus(e.target.value)} value={status} placeholder="Project Status" className='input' />
                    <input type="file" accept="image/*" onChange={handleImageChange} className='input' />
                    {error && <p className="text-red-500">{error}</p>}
                    <div className='flex items-center justify-center gap-6'>
                        <button className='btn' onClick={onClose} type="reset">Cancel</button>
                        <button type='submit' className='btn'>Done</button>
                    </div>
                </form>
            </Modal>
        </div>
    );
}

export default AddProject;
