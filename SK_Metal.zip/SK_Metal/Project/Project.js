import React, { useState } from 'react';
import { db } from '../Config/firebase';
import { doc, deleteDoc } from 'firebase/firestore';
import MakeSure from "../Components/MakeSure.js"; // Adjust the path accordingly

function Project({ id, title, startDate, endDate, status, imageUrl, completed }) {
    const [open, setOpen] = useState({ edit: false, view: false });
    const [popup, setPopup] = useState(false);

    const handleDelete = async () => {
        const projectDocRef = doc(db, 'projects', id);
        try {
            await deleteDoc(projectDocRef);
        } catch (err) {
            alert(err);
        }
    };
    
    const handlePopup = () => {
        setPopup(!popup);
    };

    return (
        <div className='rounded shadow-md border-[10px] flex w-[15rem] h-[18rem] pt-12'>
            <div className='flex w-full h-full flex-wrap'>
                <div className='w-full h-full flex flex-col justify-evenly items-center'>
                    <div>
                        <img src={imageUrl} alt={title} className="w-full h-[10rem] object-cover rounded" /> {/* Display image */}
                        <p className="text-[1.2rem] font-xl capitalize">Title: {title}</p>
                        <p className="text-[1.2rem] font-xl">Status: {status}</p>
                        <p className="text-[1.2rem] font-xl">Start Date: {startDate}</p>
                        <p className="text-[1.2rem] font-xl">End Date: {endDate}</p>
                    </div>
                    <div className='flex w-full justify-evenly'>
                        <button onClick={() => setOpen({ ...open, view: true })} className='btn-1'>View</button>
                        <button onClick={() => setOpen({ ...open, edit: true })} className='btn-1 bg-light-gray'>Edit</button>
                        <button onClick={handlePopup} className='btn-1 bg-yellow text-black'>Delete</button>
                    </div>
                </div>
            </div>
            {popup && <MakeSure handleDelete={handleDelete} handlePopup={handlePopup} />}
        </div>
    );
}

export default Project;
