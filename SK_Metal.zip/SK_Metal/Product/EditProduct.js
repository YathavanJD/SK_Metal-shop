// src/Product/EditProduct.js
import { useState } from 'react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../Config/firebase';
import Modal from './Modal';

function EditProduct({ open, onClose, toEditTitle, toEditPrice, id }) {
    const [title, setTitle] = useState(toEditTitle);
    const [price, setPrice] = useState(toEditPrice);

    const handleUpdate = async (e) => {
        e.preventDefault();
        try {
            await updateDoc(doc(db, 'products', id), { title, price });
            onClose();
        } catch (err) {
            alert("Error updating product.");
        }
    };

    return (
        <Modal modalLable='Edit Product' onClose={onClose} open={open}>
            <form onSubmit={handleUpdate} className="form">
                <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Product Name" />
                <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Price" />
                <button type="submit">Update</button>
            </form>
        </Modal>
    );
}

export default EditProduct;
