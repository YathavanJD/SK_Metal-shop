import Modal from './Modal';

function ViewProduct({ open, onClose, title, price, imageUrl }) {
    if (!open) return null;

    return (
        <Modal modalLable='View Product' onClose={onClose} open={open}>
            <div className='p-6 flex flex-col items-center'>
                <img src={imageUrl} alt={title} className="w-full h-40 object-cover mb-4" />
                <h2 className='text-2xl font-bold mb-2'>{title}</h2>
                <p className='text-gray-700 mb-4'>Price: {price}</p>
                <button className='px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700' onClick={onClose}>Close</button>
            </div>
        </Modal>
    );
}

export default ViewProduct;
