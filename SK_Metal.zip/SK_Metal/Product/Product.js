import { useState } from 'react';
import EditProduct from './EditProduct';
import ViewProduct from './ViewProduct'; // Import the new ViewProduct component
import { db } from '../Config/firebase';
import { doc, deleteDoc } from 'firebase/firestore';

function Product({ title, price, imageUrl, id }) {
    const [openEditModal, setOpenEditModal] = useState(false);
    const [openViewModal, setOpenViewModal] = useState(false);

    const handleDelete = async () => {
        try {
            await deleteDoc(doc(db, 'products', id));
            alert("Product deleted successfully!");
        } catch (err) {
            alert("Error deleting product.");
        }
    };

    return (
        <div className='rounded shadow-md border-[10px] w-[20rem] p-6 bg-white'>
            <img src={imageUrl} alt={title} className="w-full h-40 object-cover mb-4" />
            <p className='font-bold text-lg mb-2'>{title}</p>
            <p className='text-gray-700 mb-4'>Price: {price}</p>
            <div className='flex space-x-2'>
                <button className='px-2 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-700' onClick={() => setOpenEditModal(true)}>Edit</button>
                <button className='px-2 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-700' onClick={handleDelete}>Delete</button>
                <button className='px-2 py-1 bg-green-500 text-white rounded text-sm hover:bg-green-700' onClick={() => setOpenViewModal(true)}>View</button>
            </div>
            {openEditModal && 
                <EditProduct 
                    open={openEditModal} 
                    onClose={() => setOpenEditModal(false)} 
                    toEditTitle={title} 
                    toEditPrice={price} 
                    id={id} 
                />
            }
            {openViewModal &&
                <ViewProduct
                    open={openViewModal}
                    onClose={() => setOpenViewModal(false)}
                    title={title}
                    price={price}
                    imageUrl={imageUrl}
                />
            }
        </div>
    );
}

export default Product;
