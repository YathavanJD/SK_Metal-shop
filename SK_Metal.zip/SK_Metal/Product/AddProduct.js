import { useState } from 'react';
import { collection, addDoc, Timestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../Config/firebase';
import Modal from './Modal';

function AddProduct({ onClose, open }) {
    const [title, setTitle] = useState('');
    const [price, setPrice] = useState('');
    const [image, setImage] = useState(null);
    const [error, setError] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!title || !price || !image) {
            setError('All fields are required!');
            return;
        }
        try {
            setError(null);
            const imageRef = ref(storage, `images/${image.name}`);
            await uploadBytes(imageRef, image);
            const imageUrl = await getDownloadURL(imageRef);
            await addDoc(collection(db, 'products'), {
                title,
                price,
                imageUrl,
                created: Timestamp.now(),
            });
            onClose();
        } catch (err) {
            setError('Error adding product. Please try again.');
        }
    };

    return (
        <Modal modalLable='Add Product' onClose={onClose} open={open}>
            <form onSubmit={handleSubmit} className="space-y-4 p-4">
                <div className="flex flex-col">
                    <label className="mb-1 text-blue-700">Product Name</label>
                    <input
                        type="text"
                        onChange={(e) => setTitle(e.target.value)}
                        value={title}
                        placeholder="Product Name"
                        className='p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500'
                    />
                </div>
                <div className="flex flex-col">
                    <label className="mb-1 text-blue-700">Price</label>
                    <input
                        type="number"
                        onChange={(e) => setPrice(e.target.value)}
                        value={price}
                        placeholder="Price"
                        className='p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500'
                    />
                </div>
                <div className="flex flex-col">
                    <label className="mb-1 text-blue-700">Image</label>
                    <input
                        type="file"
                        onChange={(e) => setImage(e.target.files[0])}
                        className='p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500'
                    />
                </div>
                {error && <p className="text-red-500">{error}</p>}
                <button type="submit" className='px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700 transition-all duration-300'>
                    Add Product
                </button>
            </form>
        </Modal>
    );
}

export default AddProduct;
